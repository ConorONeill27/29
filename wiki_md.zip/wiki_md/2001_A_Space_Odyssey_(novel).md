# 2001: A Space Odyssey (novel)

For the film, see 2001: A Space Odyssey (Film).

2001: A Space Odyssey is a 1968 science fiction novel by British writer Arthur C. Clarke. It was developed concurrently with Stanley Kubrick's film version and published after the release of the film. Clarke and Kubrick worked on the book together, but eventually only Clarke ended up as the official author. The story is based in part on various short stories by Clarke, including "The Sentinel" (written in 1948 for a BBC competition, but first published in 1951 under the title "Sentinel of Eternity"). By 1992, the novel had sold three million copies worldwide. An elaboration of Clarke and Kubrick's collaborative work on this project was made in the 1972 book The Lost Worlds of 2001.
The first part of the novel, in which aliens influence the primitive ancestors of humans, is similar to the plot of Clarke's 1953 short story "Encounter in the Dawn".


== Plot summary ==
A mysterious alien civilization uses a tool with the appearance of a large crystalline monolith to investigate worlds across the galaxy and, if possible, to encourage the development of intelligent life. The book shows one such monolith appearing in prehistoric Africa, three million years ago, where it inspires a starving group of hominids to develop tools. The hominids use their tools to kill animals and eat meat, ending their starvation. They then use the tools to kill a leopard preying on them; the next day, the main ape character, Moon-Watcher, uses a club to kill the leader of a rival tribe.
In AD 1999, Dr. Heywood Floyd travels to the Moon's Clavius Base, where a scientist explains that they have found an electromagnetic disturbance, designated Tycho Magnetic Anomaly One (or TMA-1), near the crater Tycho. Excavation has revealed a large black slab, precisely fashioned to a ratio of 1:4:9 (or 12:22:32) and therefore believed the work of intelligence. Visiting TMA-1, Floyd and others arrive just as sunlight falls upon it for the first time since it was uncovered; it emits a piercing radio transmission which the scientists determine is directed at Iapetus, a moon of Saturn.
A mission, Discovery One, is sent to Iapetus. En route, Dr. David Bowman and Dr. Frank Poole are the only conscious humans aboard; their three colleagues are in suspended animation, to be awakened near Jupiter. The HAL 9000, an artificially intelligent computer addressed as "Hal", maintains the ship. The first stages of the mission are achieved as planned and on schedule.
While Poole is receiving a birthday message from his family on Earth, Hal tells Bowman that the AE-35 communication unit of the ship is going to malfunction. Poole takes one of the extra-vehicular pods and swaps the AE-35 unit; but when Bowman conducts tests on the removed AE-35 unit, he determines that there was never anything wrong with it. Poole and Bowman become suspicious at Hal's refusal to admit that his diagnosis was mistaken.
As Poole is replacing the unit, he is killed when his pod accelerates into him, crushing him. Bowman, uncertain of Hal's role therein, decides to wake the other three astronauts, and therefore quarrels with Hal, with Hal refusing to obey his orders. Bowman threatens to disconnect him if his orders are not obeyed, and Hal relents. As Bowman begins to awaken his colleagues, he hears Hal open both airlocks into space, releasing the ship's internal atmosphere. From a sealed emergency shelter, Bowman gains a spacesuit and re-enters the ship, where he shuts down Hal's consciousness, leaving intact only his autonomic functions, and manually re-establishes contact with Earth. He then learns that his mission is to explore Iapetus, in the hope of contacting the society that buried the monolith on the Moon. Bowman learns that Hal had begun to feel guilty at keeping the purpose of the mission from him and Poole, against his stated mission of gathering information and reporting it fully; and when threatened with disconnection, he panicked and defended himself out of a belief that his very existence was at stake, having no concept of sleep.
Bowman spends months on the ship alone, slowly approaching Iapetus. During his approach, he gradually notices a small black spot on the surface of Iapetus, and later finds it identical in shape to TMA-1, only much larger. The scientists on Earth name this monolith "TMA-2", which Bowman identifies as a double misnomer because it is not in the Tycho crater and gives off no magnetic anomaly. When Bowman approaches the monolith, it opens and pulls in Bowman's pod. Before he vanishes, Mission Control hears him proclaim: "The thing's hollow – it goes on forever – and – oh my God! – it's full of stars!"
Bowman is transported via the monolith to an unknown star system, through a large interstellar switching station, and sees other species' spaceships going on other routes. Bowman is given a wide variety of sights, from the wreckage of ancient civilizations to what appear to be life-forms, living on the surfaces of a binary star system's planet. He is brought to what appears a pleasant hotel suite, carefully designed to make him feel at ease, and falls asleep, whereupon he becomes an immortal "Star-Child" that can live and travel in space. The Star Child then returns to Earth, where he is attacked by an atomic device  aimed at him by the people on earth to which he is impervious.[p.223]. And then he thinks what else he might do.


== Themes ==
Perils of technology
2001: A Space Odyssey explores technological advancement:  its promise and its danger. The HAL 9000 computer puts forward the troubles that can crop up when humans build machines, the inner workings of which are not fully comprehended and therefore cannot fully be controlled.

Perils of nuclear war
The book explores the perils related to the atomic age. In this novel, the Cold War is apparently still on, and at the end of the book one side has nuclear weapons above the earth on an orbital platform. To test its abilities, the Star Child detonates an orbiting warhead at the end of the novel, creating a false dawn below for the people on Earth. Roger Ebert notes that Kubrick originally intended for the first spaceship seen in the film to be an orbiting bomb platform, but in the end he decided to leave the ship's meaning more ambiguous. Clarke, however, retained and clearly stated this fact in the novel.

Evolution
The novel takes a panoramic overview of progress, human and otherwise. The story follows the growth of human civilization from primitive hominids. Distinctively, Space Odyssey is concerned about not only the evolution that has led to the development of humanity, but also the evolution that humanity might undergo in the future. Hence, we follow Bowman as he is turned into a Star Child. The novel acknowledges that evolutionary theory entails that humanity is not the end, but only a step in the process. One way this process might continue, the book imagines, is that humans will learn to move to robot bodies and eventually rid themselves of a physical form altogether.

Space exploration
When 2001: A Space Odyssey was written, humankind had not yet set foot on the Moon. The space exploration programs in the United States and the Soviet Union were only in the early stages. Much room was left to imagine the future of the space program. Space Odyssey offers one such vision, offering a glimpse at what space exploration might one day become. Lengthy journeys, such as crewed flights to Saturn, and advanced technologies, such as suspended animation, are described in the novel.

Artificial intelligence
The book raises questions about consciousness, sentience, and human interactions with machines. Hal's helpful disposition contrasts with his malevolent behaviour. Through much of the movie he seems to have malfunctioned. At the end of the novel we learn that Hal's odd behaviour stems from an improper conflict in his orders. Having been instructed not to reveal the nature of the mission to his crew, he reasons that their presence is a threat to the mission, which is his prime concern. Hal's reversion to a childlike state as Dave shuts him down mirrors aspects of human death, and his expressed fear of being shut down causes Dave to hesitate.

Accoutrements of space-travel
The novel is deliberately written so as to give the reader an almost kinesthetic familiarity with the experience of space travel and the technologies encountered. Large sections of the novel are devoted to detailed descriptions of these. The novel discusses orbital mechanics and the manoeuvres associated with space travel with great scientific accuracy. The daily lives of Bowman and Poole on board the Discovery One are discussed in detail and give the impression of a busy yet mundane lifestyle with few surprises until the malfunction of Hal. Dr. Floyd's journey to Space Station One is depicted with awareness of fine points such as the experience of a Space Shuttle launch, the adhesive sauces used to keep food firmly in place on one's plate, and even the zero-gravity toilet.


== Characters ==


=== Main-characters ===
Moon-Watcher: An Australopithecus africanus man-ape who lived in dry equatorial Africa, circa 3,000,000 BC. He, his tribe, and his species were faced with extinction, but for the intervention of a monolith which imbued him and his fellows with the beginnings of higher intelligence.  Evolution then took its course.
Dr. Heywood Floyd: Astronomer and chairman of the "National Council of Astronautics", who is flown from the Earth to the Moon on a secret mission concerning the Tycho monolith, or TMA-1, a second monolith which has been discovered on the Moon, and excavated by an American geological survey team from Clavius Base. In Floyd's presence, the Tycho monolith, being struck by sunlight for the first time in three million years, sends an extremely powerful energy burst in the direction of Saturn.
David Bowman/Star-Child: First Captain of the Discovery, an American spacecraft which had previously been intended to visit the Jupiter system, but which has recently instead been charged with exploring Saturn.  Unbeknownst to Bowman and his deputy Frank Poole, the true objective of the mission is reconnaissance of Saturn space, implicated by the above energy signal direction, where it is thought that further clues to the aliens' intent may be found. Bowman becomes the Star Child after entering the Iapetus monolith (TMA-2).
Frank Poole: Bowman's deputy.  Bowman and Poole routinely toggle shifts and roles in order to maintain a continuous, waking presence on board the Discovery.  Poole is attacked and seemingly killed by HAL while performing EVA maintenance.
HAL 9000: The Discovery's intelligent, on board ship's computer, capable of monitoring all ship functions, and holding conversations and maintaining relationships with human beings.  HAL malfunctions, killing all crew members with the exception of Bowman; this was a result both of HAL being entrusted with the true objective of the Discovery's mission, and also of being charged with keeping it a secret until the appropriate time.  These orders conflict with HAL's basic purpose, which is the accurate and complete communication of information to humans.


=== Minor characters ===
Over the course of the novel, several minor characters either appear very briefly or are named only in passing, including other man-apes, spaceflight staff, lunar station security, and Discovery crew members.  Among the novel's minor characters, some of the more consequential are listed below (often having direct film equivalents, or else being recurring characters in the Odyssey novel series).

One-Ear: The leader of the "Others", a rival tribe of Australopithecus africanus man-apes, thus the enemy of Moon-Watcher and his tribe. Aside from his eponymic disfigurement, One-Ear is described as being the same age and size as Moon-Watcher, but in "poorer shape". Inter-tribal confrontations reveal a leadership style characterized by concealing his fear behind either screeching bravado or "exaggerated dignity". When faced with his most lethal opponent, One-Ear appears to be either "too brave or too stupid to run".  None of the Others, including One-Ear, are depicted as being evaluated or transformed by a monolith.
Dr. Dimitri Moisevitch: A good friend of Floyd's (and citizen of the rival U.S.S.R.), who diplomatically presses Floyd about the Americans' "outbreak" cover story (intended to keep outsiders away from the discovery of the Tycho monolith) while both are aboard Space Station One, a stopping-point between the Earth and the Moon.  In the film, Moisevitch's role is carried out by a character of a different name, Dr. Andrey Smislov, while the character of Moisevitch as-such makes appearances throughout the rest of the Odyssey series and in the opening scene of the 2010 film.  Moisevitch, like Floyd, is written as a cagey and worldly bureaucrat.
Ralph Halvorsen: Administrator of the Southern Province and leader of Clavius Base, Halvorsen represents American interests on the Moon, and receives Floyd at Clavius to gather information about the Tycho monolith.
Whitehead, Kaminski, and Hunter: a trio of astronauts who are put aboard the Discovery in hibernation, in order to conserve resources.  In the event of the deaths of Bowman or Poole, the hibernating astronauts are to be revived in the order given.  Consequently, upon Poole's presumptive death, Bowman partially revived Whitehead until HAL depressurized the Discovery, killing the three while Bowman escaped to a secure area.  In the film, HAL kills the trio by simply shutting off their life support functions while Bowman is on EVA in an effort to recover Poole's body; in the film, the trio are instead styled as Kimball, Kaminsky, and Hunter.
Dr. Chandra: Briefly cited by HAL during his de-activation as being his first instructor, who taught him to sing "Daisy".  In the film, this initial instructor is instead named as "Mr. Langley"; however the character of Dr. Chandra features throughout the rest of the Odyssey franchise, especially in the 2010 book and film.
Anna, Betty, Clara: The namesakes of the Discovery's three EVA pods.  In other films and novels of the franchise, these pods are given different naming conventions.  Betty is the pod which, under HAL's control, presumptively causes Poole's death.


== Sequels ==
2010: Odyssey Two, a 1982 sequel to the book, was adapted as a motion picture in 1984. Clarke went on to write two more sequel novels: 2061: Odyssey Three (1987) and 3001: The Final Odyssey (1997). To date, the last two novels have yet to be adapted as films.


== Reception ==
James Blish commented that while Clarke's narrative provided essential elements of the story that Kubrick ignored or glossed over, "The novel has very little of the poetry of the picture" and "lacks most of the picture's strengths", but that "it has to be read before one can understand the picture".
Eliot Fremont-Smith reviewed the book positively in the New York Times, stating that it was "a fantasy by a master who is as deft at generating accelerating, almost painful suspense as he is knowledgeable and accurate (and fascinating) about the technical and human details of space flight and exploration".


== Differences from the film ==

Although the novel and film were developed simultaneously, the novel follows early drafts of the film, from which the final version of the film deviated. These changes were often for practical reasons relating to what could be filmed economically, and a few were due to differences of opinion between Kubrick and Clarke. The most notable differences are a change in the destination planet from Saturn to Jupiter, and the nature of the sequence of events leading to HAL's demise. Stylistic differences may be more important than content differences. 
Stylistically, the novel generally fleshes out and makes concrete many events left somewhat enigmatic in the film, as has been noted by many observers. Vincent LoBrutto has noted that the novel has "strong narrative structure" which fleshes out the story, while the film is a mainly visual experience where much remains "symbolic". Randy Rasmussen has noted that the personality of Heywood Floyd is different; in Clarke's novel, he finds space-travel thrilling, acting almost as a "spokesman for Clarke", whereas in the film, he experiences space travel as "routine" and "tedious".
In the film, Discovery's mission is to Jupiter, not Saturn. Kubrick used Jupiter because he and special effects supervisor Douglas Trumbull could not decide on what they considered to be a convincing model of Saturn's rings for the film. Clarke went on to replace Saturn with Jupiter in the novel's sequel 2010: Odyssey Two. Trumbull later developed a more convincing image of Saturn for his own directorial debut Silent Running.
The general sequence of the showdown with HAL is different in the film from in the book. HAL's initial assertion that the AE-35 unit will fail comes in the film after an extended conversation with David Bowman about the odd and "melodramatic" "mysteries" and "secrecy" surrounding the mission, motivated officially because HAL is required to draw up and send to Earth a crew psychology report. In the novel it is during the birthday-message to Frank Poole.
In the film, Bowman and Poole decide on their own to disconnect HAL in context of a plan to restore the allegedly failing antenna unit. If it does not fail, HAL will be shown to be malfunctioning. HAL discovers the plan by reading their lips through the EVA pod window. In Clarke's novel, Ground-Control orders Bowman and Poole to disconnect HAL, should he prove to be malfunctioning a second time by predicting that the second unit is going to fail.
However, in Clarke's novel, after Poole's death, Bowman tries waking up the other crew members, whereupon HAL opens both the internal and external airlock doors, suffocating these three and almost killing Bowman. The film has Bowman, after Poole's murder, go out to rescue him. HAL denies him reentry and kills the hibernating crew members by turning off their life-support. In the sequel 2010: Odyssey Two, however, the recounting of the Discovery One mission is changed to be in line with the film version.
The film is generally far more enigmatic about the reason for HAL's failure, while the novel spells out that HAL is caught up in an internal conflict because he is ordered to lie about the purpose of the mission.
Because of what photographed well, the appearance of the monolith that guided Moon-watcher and the other 'man-apes' at the beginning of the story was changed from novel to film. In the novel, this monolith is a transparent crystal; in the film, it is solid black. The TMA1 and TMA2 monoliths were unchanged.
In the book, HAL became operational on 12 January 1997, but in the movie the year is given as 1992. It has been thought that Kubrick wanted HAL to be the same age as a young bright child, nine years old.
In the book, Heywood took a ground vehicle for the 200-mile-journey from Clavius Base to TMA-1, a mobile lab "rolling across the crater plain at fifty miles an hour" that resembles "an outsized trailer mounted on eight flex-wheels" and is capable of hopping across obstacles "on its four under-jets".  The vehicle is referred to as a "bus".  In the film, however, Heywood took a wingless shuttle that flies the entire 200-mile journey. Even at moon-gravity, such flying may not be technically or economically feasible.
In the book, the Discovery spacecraft has large "dragonfly wing like" radiator panels to prevent its high temperature nuclear reactor propulsion system from melting. The film originally also featured radiators but Kubrick removed them since he wanted to avoid the appearance of "wings" on a spacecraft intended for deep space missions only.


== Iapetus versus Japetus ==
The name of the Saturnian moon Iapetus is spelled Japetus in the novel. This is an alternative rendering of the name, which derives from the fact that "consonantal I" often stands for "J" in the Latin language (see modern spelling of Latin).
In his detailed 1970 book on the film, The Making of Kubrick's 2001, author Jerome Agel discusses the point that Iapetus is the most common rendering of the name, according to many sources, including the Oxford English Dictionary. He goes on to say that "Clarke, the perfectionist", spells it Japetus. Agel then cites the dictionary that defines jape as "to jest; to joke; to mock or make fun of". He then asks the reader, "Is Clarke trying to tell us something?"
Clarke himself directly addressed the spelling issue in chapter 19 of The Lost Worlds of 2001, explaining that he simply (and unconsciously) used the spelling he was familiar with from The Conquest of Space (1949) by Willy Ley and Chesley Bonestell, presuming that the "J" form is the German rendering of the Greek.


== Release details ==
1968, USA, New American Library (ISBN 978-0-453-00269-1), June 1968, hardback (First edition)
1968, USA, Signet, July 1968, paperback (First paperback edition)
1968, UK, Hutchinson (ISBN 978-0-09-089830-5), 1968, hardback (First British edition)
1968, UK, Arrow Books (ISBN 978-0-09-001530-6), October 1968, paperback
1976, Arrow Books (ISBN 978-0-09-906610-1), August 1976, paperback
1982, Roc (ISBN 978-0-451-11864-6), November 1982, paperback
1985, Ediciones Orbis – Hyspamerica (ISBN 978-84-7634-053-0), paperback, Spanish Language edition (2001: Una odisea espacial) translated by Antonio Ribera
1990, Orbit (ISBN 978-1-85723-664-4), July 1990, paperback
1993, USA, Roc (ISBN 978-0-451-45273-3), August 1993, hardback (25th Anniversary Edition)
1993, USA, Turtleback Books (ISBN 978-0-606-16008-7), August 1993, hardback
1998, İthaki Yayınları (ISBN 978-975-6902-01-1), October 1998, paperback, Turkish Language edition (2001: Bir Uzay Efsanesi) translated by Ardan Tüzünsoy
1999, USA, New American Library, (ISBN 978-0-451-19849-5), October 1999, hardback
2000, USA, Roc (ISBN 978-0-451-45799-8), September 2000, paperback
2000, UK, Orbit (ISBN 978-1-84149-055-7), December 2000, hardback (special edition)
2001, Roc (ASIN B01A6E8EQ6), September 2001, Kindle edition
2004, المؤسسة العربية الحديثة للطبع والنشر والتوزيع, January 2004, Arabic language edition (أوديسا الفضاء) translated by أحمد خالد توفيق
2005, USA, Signet (ISBN 978-0-451-45273-3), July 2005, paperback
2008, vis-a-vis/Etiuda (ISBN 978-83-89640-94-9), 2008, Polish language edition (2001: Odyseja kosmiczna) translated by Jędrzej Polak
2008, Brilliance Audio (ISBN 978-1-4233-3662-4), January 2008 Audiobook narrated by Dick Hill
2008, Nord (ISBN 978-88-429-1550-8), January 2008, paperback, Italian language edition (2001: Odissea nello spazio)
2008, J'ai Lu (ISBN 978-2-290-30814-1), March 2008, paperback, French language edition (2001: L'Odyssée de l'espace)
2010, Editura Nemira (ISBN 978-606-8134-60-4), Hardcover, Romanian language edition (2001: Odiseea spaţială)
2010, Orbit (ASIN B003PPDIC4), June 2010, Kindle edition
2012 Rosetta Books (ASIN B00ANA27IU), 2012, Kindle edition
2013, BR, Aleph (ISBN 978-85-7657-155-1), October 2013, Brazilian Portuguese language edition (2001: Uma Odisséia no Espaço) translated by Fábio Fernandes
2016, Penguin Galaxy (ISBN 978-0-14-311157-3), October 2016, hardback
2016, İthaki Yayınları (ISBN 978-605-375-595-1), October 2016, paperback, Turkish language edition (2001: Bir Uzay Destanı) translated by Oya İşeri
The film 2010 was released in 1984 resulting in movie tie-in editions of both the 2001 and 2010 novels. At the time Signet Books reported that over 2.8 million copies of 2001 were in print and that 2010 was one of 1983's top sellers with 300,000 hardcover copies and 1.75 million first paperback editions printed.


== See also ==
List of fictional computers
Toynbee tiles
Childhood's End
List of stories set in a future now in the past


== References ==
Notes

Bibliography


== External links ==
Book review – Hal's Legacy: 2001's Computer as Dream and Reality
2001: A Space Odyssey title listing at the Internet Speculative Fiction Database