# Atmosphere of Earth

The atmosphere of Earth is composed of a layer of gas mixture that surrounds the Earth's planetary surface (both lands and oceans), known collectively as air, with variable quantities of suspended aerosols and particulates (which create weather features such as clouds and hazes), all retained by Earth's gravity. The atmosphere serves as a protective buffer between the Earth's surface and outer space, shields the surface from most meteoroids and ultraviolet solar radiation, keeps it warm and reduces diurnal temperature variation (temperature extremes between day and night) through heat retention (greenhouse effect), redistributes heat and moisture among different regions via air currents, and provides the chemical and climate conditions allowing life to exist and evolve on Earth.
By mole fraction (i.e., by quantity of molecules), dry air contains 78.08% nitrogen, 20.95% oxygen, 0.93% argon, 0.04% carbon dioxide, and small amounts of other trace gases (see Composition below for more detail). Air also contains a variable amount of water vapor, on average around 1% at sea level, and 0.4% over the entire atmosphere. 
Earth's early atmosphere consisted of accreted gases from the solar nebula, but the atmosphere changed significantly over time, affected by many factors such as volcanism, impact events, weathering and the evolution of life (particularly the photoautotrophs). Recently, human activity has also contributed to atmospheric changes, such as climate change (mainly through deforestation and fossil fuel-related global warming), ozone depletion and acid deposition.
The atmosphere has a mass of about 5.15×1018 kg, three quarters of which is within about 11 km (6.8 mi; 36,000 ft) of the surface. The atmosphere becomes thinner with increasing altitude, with no definite boundary between the atmosphere and outer space. The Kármán line, at 100 km (62 mi) or 1.57% of Earth's radius, is often used as the border between the atmosphere and outer space. Atmospheric effects become noticeable during atmospheric reentry of spacecraft at an altitude of around 120 km (75 mi). Several layers can be distinguished in the atmosphere based on characteristics such as temperature and composition, namely the troposphere, stratosphere, mesosphere, thermosphere (formally the ionosphere) and exosphere. Air composition, temperature and atmospheric pressure vary with altitude. Air suitable for use in photosynthesis by terrestrial plants and respiration of terrestrial animals is found within the troposphere.
The study of Earth's atmosphere and its processes is called atmospheric science (aerology), and includes multiple subfields, such as climatology and atmospheric physics. Early pioneers in the field include Léon Teisserenc de Bort and Richard Assmann. The study of historic atmosphere is called paleoclimatology.


== Composition ==

The three major constituents of Earth's atmosphere are nitrogen, oxygen, and argon. Water vapor accounts for roughly 0.25% of the atmosphere by mass. The concentration of water vapor (a greenhouse gas) varies significantly from around 10 ppm by mole fraction in the coldest portions of the atmosphere to as much as 5% by mole fraction in hot, humid air masses, and concentrations of other atmospheric gases are typically quoted in terms of dry air (without water vapor).: 8  The remaining gases are often referred to as trace gases, among which are other greenhouse gases, principally carbon dioxide, methane, nitrous oxide, and ozone. Besides argon, other noble gases, neon, helium, krypton, and xenon are also present. Filtered air includes trace amounts of many other chemical compounds. Many substances of natural origin may be present in locally and seasonally variable small amounts as aerosols in an unfiltered air sample, including dust of mineral and organic composition, pollen and spores, sea spray, and volcanic ash. Various industrial pollutants also may be present as gases or aerosols, such as chlorine (elemental or in compounds), fluorine compounds and elemental mercury vapor. Sulfur compounds such as hydrogen sulfide and sulfur dioxide (SO2) may be derived from natural sources or from industrial air pollution.

The average molecular weight of dry air, which can be used to calculate densities or to convert between mole fraction and  mass fraction, is about 28.946 or 28.964 g/mol. This is decreased when the air is humid.
The relative concentration of gases remains constant until about 10,000 m (33,000 ft).


== Stratification ==

In general, air pressure and density decrease with altitude in the atmosphere. However, temperature has a more complicated profile with altitude and may remain relatively constant or even increase with altitude in some regions (see the temperature section). Because the general pattern of the temperature/altitude profile, or lapse rate, is constant and measurable by means of instrumented balloon soundings, the temperature behavior provides a useful metric to distinguish atmospheric layers. This atmospheric stratification divides the Earth's atmosphere into five main layers:

Exosphere: 700–10,000 km (435–6,214 mi)
Thermosphere: 80–700 km (50–435 mi)
Mesosphere: 50–80 km (31–50 mi)
Stratosphere: 12–50 km (7–31 mi)
Troposphere: 0–12 km (0–7 mi)


=== Exosphere ===

The exosphere is the outermost layer of Earth's atmosphere (though it is so tenuous that some scientists consider it to be part of interplanetary space rather than part of the atmosphere). It extends from the thermopause (also known as the "exobase") at the top of the thermosphere to a poorly defined boundary with the solar wind and interplanetary medium. The altitude of the exobase varies from about 500 kilometres (310 mi; 1,600,000 ft) to about 1,000 kilometres (620 mi) in times of higher incoming solar radiation.
The upper limit varies depending on the definition. Various authorities consider it to end at about 10,000 kilometres (6,200 mi) or about 190,000 kilometres (120,000 mi)—about halfway to the moon, where the influence of Earth's gravity is about the same as radiation pressure from sunlight. The geocorona visible in the far ultraviolet (caused by neutral hydrogen) extends to at least 100,000 kilometres (62,000 mi).
This layer is mainly composed of extremely low densities of hydrogen, helium and several heavier molecules including nitrogen, oxygen and carbon dioxide closer to the exobase. The atoms and molecules are so far apart that they can travel hundreds of kilometres without colliding with one another. Thus, the exosphere no longer behaves like a gas, and the particles constantly escape into space. These free-moving particles follow ballistic trajectories and may migrate in and out of the magnetosphere or the solar wind. Every second, the Earth loses about 3 kg of hydrogen, 50 g of helium, and much smaller amounts of other constituents.
The exosphere is too far above Earth for meteorological phenomena to be possible. However, Earth's auroras—the aurora borealis (northern lights) and aurora australis (southern lights)—sometimes occur in the lower part of the exosphere, where they overlap into the thermosphere. The exosphere contains many of the artificial satellites that orbit Earth.


=== Thermosphere ===

The thermosphere is the second-highest layer of Earth's atmosphere. It extends from the mesopause (which separates it from the mesosphere) at an altitude of about 80 km (50 mi; 260,000 ft) up to the thermopause at an altitude range of 500–1000 km (310–620 mi; 1,600,000–3,300,000 ft). The height of the thermopause varies considerably due to changes in solar activity. Because the thermopause lies at the lower boundary of the exosphere, it is also referred to as the exobase. The lower part of the thermosphere, from 80 to 550 kilometres (50 to 342 mi) above Earth's surface, contains the ionosphere.
The temperature of the thermosphere gradually increases with height and can rise as high as 1500 °C (2700 °F), though the gas molecules are so far apart that its temperature in the usual sense is not very meaningful. The air is so rarefied that an individual molecule (of oxygen, for example) travels an average of 1 kilometre (0.62 mi; 3300 ft) between collisions with other molecules. Although the thermosphere has a high proportion of molecules with high energy, it would not feel hot to a human in direct contact, because its density is too low to conduct a significant amount of energy to or from the skin.
This layer is completely cloudless and free of water vapor. However, non-hydrometeorological phenomena such as the aurora borealis and aurora australis are occasionally seen in the thermosphere. The International Space Station orbits in this layer, between 350 and 420 km (220 and 260 mi). It is this layer where many of the satellites orbiting the Earth are present.


=== Mesosphere ===

The mesosphere is the third highest layer of Earth's atmosphere, occupying the region above the stratosphere and below the thermosphere. It extends from the stratopause at an altitude of about 50 km (31 mi; 160,000 ft) to the mesopause at 80–85 km (50–53 mi; 260,000–280,000 ft) above sea level.
Temperatures drop with increasing altitude to the mesopause that marks the top of this middle layer of the atmosphere. It is the coldest place on Earth and has an average temperature around −85 °C (−120 °F; 190 K).
Just below the mesopause, the air is so cold that even the very scarce water vapor at this altitude can condense into polar-mesospheric noctilucent clouds of ice particles. These are the highest clouds in the atmosphere and may be visible to the naked eye if sunlight reflects off them about an hour or two after sunset or similarly before sunrise. They are most readily visible when the Sun is around 4 to 16 degrees below the horizon. Lightning-induced discharges known as transient luminous events (TLEs) occasionally form in the mesosphere above tropospheric thunderclouds. The mesosphere is also the layer where most meteors burn up upon atmospheric entrance. It is too high above Earth to be accessible to jet-powered aircraft and balloons, and too low to permit orbital spacecraft. The mesosphere is mainly accessed by sounding rockets and rocket-powered aircraft.


=== Stratosphere ===

The stratosphere is the second-lowest layer of Earth's atmosphere. It lies above the troposphere and is separated from it by the tropopause. This layer extends from the top of the troposphere at roughly 12 km (7.5 mi; 39,000 ft) above Earth's surface to the stratopause at an altitude of about 50 to 55 km (31 to 34 mi; 164,000 to 180,000 ft).
The atmospheric pressure at the top of the stratosphere is roughly 1/1000 the pressure at sea level. It contains the ozone layer, which is the part of Earth's atmosphere that contains relatively high concentrations of that gas. The stratosphere defines a layer in which temperatures rise with increasing altitude. This rise in temperature is caused by the absorption of ultraviolet radiation (UV) from the Sun by the ozone layer, which restricts turbulence and mixing. Although the temperature may be −60 °C (−76 °F; 210 K) at the tropopause, the top of the stratosphere is much warmer, and may be near 0 °C.
The stratospheric temperature profile creates very stable atmospheric conditions, so the stratosphere lacks the weather-producing air turbulence that is so prevalent in the troposphere. Consequently, the stratosphere is almost completely free of clouds and other forms of weather. However, polar stratospheric or nacreous clouds are occasionally seen in the lower part of this layer of the atmosphere where the air is coldest. The stratosphere is the highest layer that can be accessed by jet-powered aircraft.


=== Troposphere ===

The troposphere is the lowest layer of Earth's atmosphere. It extends from Earth's surface to an average height of about 12 km (7.5 mi; 39,000 ft), although this altitude varies from about 9 km (5.6 mi; 30,000 ft) at the geographic poles to 17 km (11 mi; 56,000 ft) at the Equator, with some variation due to weather. The troposphere is bounded above by the tropopause, a boundary marked in most places by a temperature inversion (i.e. a layer of relatively warm air above a colder one), and in others by a zone that is isothermal with height.
Although variations do occur, the temperature usually declines with increasing altitude in the troposphere because the troposphere is mostly heated through energy transfer from the surface. Thus, the lowest part of the troposphere (i.e. Earth's surface) is typically the warmest section of the troposphere. This promotes vertical mixing (hence, the origin of its name in the Greek word τρόπος, tropos, meaning "turn"). The troposphere contains roughly 80% of the mass of Earth's atmosphere. The troposphere is denser than all its overlying layers because a larger atmospheric weight sits on top of the troposphere and causes it to be most severely compressed. Fifty percent of the total mass of the atmosphere is located in the lower 5.6 km (3.5 mi; 18,000 ft) of the troposphere.
Nearly all atmospheric water vapor or moisture is found in the troposphere, so it is the layer where most of Earth's weather takes place. It has basically all the weather-associated cloud genus types generated by active wind circulation, although very tall cumulonimbus thunder clouds can penetrate the tropopause from below and rise into the lower part of the stratosphere. Most conventional aviation activity takes place in the troposphere, and it is the only layer accessible by propeller-driven aircraft.


=== Other layers ===
Within the five principal layers above, which are largely determined by temperature, several secondary layers may be distinguished by other properties:

The ozone layer is contained within the stratosphere. In this layer ozone concentrations are about 2 to 8 parts per million, which is much higher than in the lower atmosphere but still very small compared to the main components of the atmosphere. It is mainly located in the lower portion of the stratosphere from about 15–35 km (9.3–21.7 mi; 49,000–115,000 ft), though the thickness varies seasonally and geographically. About 90% of the ozone in Earth's atmosphere is contained in the stratosphere.
The ionosphere is a region of the atmosphere that is ionized by solar radiation. It is responsible for auroras. During daytime hours, it stretches from 50 to 1,000 km (31 to 621 mi; 160,000 to 3,280,000 ft) and includes the mesosphere, thermosphere, and parts of the exosphere. However, ionization in the mesosphere largely ceases during the night, so auroras are normally seen only in the thermosphere and lower exosphere. The ionosphere forms the inner edge of the magnetosphere. It has practical importance because it influences, for example, radio propagation on Earth.
The homosphere and heterosphere are defined by whether the atmospheric gases are well mixed. The surface-based homosphere includes the troposphere, stratosphere, mesosphere, and the lowest part of the thermosphere, where the chemical composition of the atmosphere does not depend on molecular weight because the gases are mixed by turbulence. This relatively homogeneous layer ends at the turbopause found at about 100 km (62 mi; 330,000 ft), the very edge of space itself as accepted by the FAI, which places it about 20 km (12 mi; 66,000 ft) above the mesopause.
Above this altitude lies the heterosphere, which includes the exosphere and most of the thermosphere. Here, the chemical composition varies with altitude. This is because the distance that particles can move without colliding with one another is large compared with the size of motions that cause mixing. This allows the gases to stratify by molecular weight, with the heavier ones, such as oxygen and nitrogen, present only near the bottom of the heterosphere. The upper part of the heterosphere is composed almost completely of hydrogen, the lightest element.
The planetary boundary layer is the part of the troposphere that is closest to Earth's surface and is directly affected by it, mainly through turbulent diffusion. During the day the planetary boundary layer usually is well-mixed, whereas at night it becomes stably stratified with weak or intermittent mixing. The depth of the planetary boundary layer ranges from as little as about 100 metres (330 ft) on clear, calm nights to 3,000 m (9,800 ft) or more during the afternoon in dry regions.
The average temperature of the atmosphere at Earth's surface is 14 °C (57 °F; 287 K) or 15 °C (59 °F; 288 K), depending on the reference.


== Physical properties ==


=== Pressure and thickness ===

The average atmospheric pressure at sea level is defined by the International Standard Atmosphere as 101325 pascals (760.00 Torr; 14.6959 psi; 760.00 mmHg). This is sometimes referred to as a unit of standard atmospheres (atm). Total atmospheric mass is 5.1480×1018 kg (1.13494×1019 lb), about 2.5% less than would be inferred from the average sea-level pressure and Earth's area of 51007.2 megahectares, this portion being displaced by Earth's mountainous terrain. Atmospheric pressure is the total weight of the air above unit area at the point where the pressure is measured. Thus air pressure varies with location and weather.
If the entire mass of the atmosphere had a uniform density equal to sea-level density (about 1.2 kg/m3) from sea level upwards, it would terminate abruptly at an altitude of 8.50 km (27,900 ft).
Air pressure actually decreases exponentially with altitude, for altitudes up to around 70 km (43 mi; 230,000 ft), dropping by half every 5.6 km (18,000 ft), or by a factor of 1/e ≈ 0.368 every 7.64 km (25,100 ft), which is called the scale height. However, the atmosphere is more accurately modeled with a customized equation for each layer that takes gradients of temperature, molecular composition, solar radiation and gravity into account. At heights over 100 km, an atmosphere may no longer be well mixed. Then each chemical species has its own scale height.
In summary, the mass of Earth's atmosphere is distributed approximately as follows:

50% is below 5.6 km (18,000 ft),
90% is below 16 km (52,000 ft),
99.99997% is below 100 km (62 mi; 330,000 ft), the Kármán line. By international convention, this marks the beginning of space where human travelers are considered astronauts.
By comparison, the summit of Mount Everest is at 8,848 m (29,029 ft); commercial airliners typically cruise between 10 and 13 km (33,000 and 43,000 ft), where the lower density and temperature of the air improve fuel economy; weather balloons reach 30.4 km (100,000 ft) and above; and the highest X-15 flight in 1963 reached 108.0 km (354,300 ft).
Even above the Kármán line, significant atmospheric effects such as auroras still occur. Meteors begin to glow in this region, though the larger ones may not burn up until they penetrate more deeply. The various layers of Earth's ionosphere, important to HF radio propagation, begin below 100 km and extend beyond 500 km. By comparison, the International Space Station and Space Shuttle typically orbit at 350–400 km, within the F-layer of the ionosphere, where they encounter enough atmospheric drag to require reboosts every few months, otherwise orbital decay will occur, resulting in a return to Earth. Depending on solar activity, satellites can experience noticeable atmospheric drag at altitudes as high as 700–800 km.


=== Temperature ===

The division of the atmosphere into layers mostly by reference to temperature is discussed above. Temperature decreases with altitude starting at sea level, but variations in this trend begin above 11 km, where the temperature stabilizes over a large vertical distance through the rest of the troposphere. In the stratosphere, starting above about 20 km, the temperature increases with height, due to heating within the ozone layer caused by the capture of significant ultraviolet radiation from the Sun by the dioxygen and ozone gas in this region. Still another region of increasing temperature with altitude occurs at very high altitudes, in the aptly-named thermosphere above 90 km.


==== Speed of sound ====

Because in an ideal gas of constant composition the speed of sound depends only on temperature and not on pressure or density, the speed of sound in the atmosphere with altitude takes on the form of the complicated temperature profile (see illustration to the right), and does not mirror altitudinal changes in density or pressure.


=== Density and mass ===

The density of air at sea level is about 1.2 kg/m3 (1.2 g/L, 0.0012 g/cm3). Density is not measured directly but is calculated from measurements of temperature, pressure and humidity using the equation of state for air (a form of the ideal gas law). Atmospheric density decreases as the altitude increases. This variation can be approximately modeled using the barometric formula. More sophisticated models are used to predict the orbital decay of satellites.
The average mass of the atmosphere is about 5 quadrillion (5×1015) tonnes or 1/1,200,000 the mass of Earth. According to the American National Center for Atmospheric Research, "The total mean mass of the atmosphere is 5.1480×1018 kg with an annual range due to water vapor of 1.2 or 1.5×1015 kg, depending on whether surface pressure or water vapor data are used; somewhat smaller than the previous estimate. The mean mass of water vapor is estimated as 1.27×1016 kg and the dry air mass as 5.1352 ±0.0003×1018 kg."


=== Tabulated properties ===


== Optical properties ==

Solar radiation (or sunlight) is the energy Earth receives from the Sun. Earth also emits radiation back into space, but at longer wavelengths that humans cannot see. Part of the incoming and emitted radiation is absorbed or reflected by the atmosphere. In May 2017, glints of light, seen as twinkling from an orbiting satellite a million miles away, were found to be reflected light from ice crystals in the atmosphere.


=== Scattering ===

When light passes through Earth's atmosphere, photons interact with it through scattering. If the light does not interact with the atmosphere, it is called direct radiation and is what you see if you were to look directly at the Sun. Indirect radiation is light that has been scattered in the atmosphere. For example, on an overcast day when you cannot see your shadow, there is no direct radiation reaching you, it has all been scattered. As another example, due to a phenomenon called Rayleigh scattering, shorter (blue) wavelengths scatter more easily than longer (red) wavelengths. This is why the sky looks blue; you are seeing scattered blue light. This is also why sunsets are red. Because the Sun is close to the horizon, the Sun's rays pass through more atmosphere than normal before reaching your eye. Much of the blue light has been scattered out, leaving the red light in a sunset.


=== Absorption ===

Different molecules absorb different wavelengths of radiation. For example, O2 and O3 absorb almost all radiation with wavelengths shorter than 300 nanometres. Water (H2O) absorbs at many wavelengths above 700 nm. When a molecule absorbs a photon, it increases the energy of the molecule. This heats the atmosphere, but the atmosphere also cools by emitting radiation, as discussed below.
The combined absorption spectra of the gases in the atmosphere leave "windows" of low opacity, allowing the transmission of only certain bands of light. The optical window runs from around 300 nm (ultraviolet-C) up into the range humans can see, the visible spectrum (commonly called light), at roughly 400–700 nm and continues to the infrared to around 1100 nm. There are also infrared and radio windows that transmit some infrared and radio waves at longer wavelengths. For example, the radio window runs from about one centimetre to about eleven-metre waves.


=== Emission ===

Emission is the opposite of absorption, it is when an object emits radiation. Objects tend to emit amounts and wavelengths of radiation depending on their "black body" emission curves, therefore hotter objects tend to emit more radiation, with shorter wavelengths. Colder objects emit less radiation, with longer wavelengths. For example, the Sun is approximately 6,000 K (5,730 °C; 10,340 °F), its radiation peaks near 500 nm, and is visible to the human eye. Earth is approximately 290 K (17 °C; 62 °F), so its radiation peaks near 10,000 nm, and is much too long to be visible to humans.
Because of its temperature, the atmosphere emits infrared radiation. For example, on clear nights Earth's surface cools down faster than on cloudy nights. This is because clouds (H2O) are strong absorbers and emitters of infrared radiation. This is also why it becomes colder at night at higher elevations.
The greenhouse effect is directly related to this absorption and emission effect. Some gases in the atmosphere absorb and emit infrared radiation, but do not interact with sunlight in the visible spectrum. Common examples of these are CO2 and H2O.


=== Refractive index ===

The refractive index of air is close to, but just greater than, 1. Systematic variations in the refractive index can lead to the bending of light rays over long optical paths. One example is that, under some circumstances, observers on board ships can see other vessels just over the horizon because light is refracted in the same direction as the curvature of Earth's surface.
The refractive index of air depends on temperature, giving rise to refraction effects when the temperature gradient is large. An example of such effects is the mirage.


== Circulation ==

Atmospheric circulation is the large-scale movement of air through the troposphere, and the means (with ocean circulation) by which heat is distributed around Earth. The large-scale structure of the atmospheric circulation varies from year to year, but the basic structure remains fairly constant because it is determined by Earth's rotation rate and the difference in solar radiation between the equator and poles.


== Evolution of Earth's atmosphere ==


=== Earliest atmosphere ===
The first atmosphere, during the Early Earth's Hadean eon, consisted of gases in the solar nebula, primarily hydrogen, and probably simple hydrides such as those now found in the gas giants (Jupiter and Saturn), notably water vapor, methane and ammonia.
During this earliest era, the Moon-forming collision and numerous impacts with large meteorites heated the atmosphere, driving off the most volatile gases. The collision with Theia, in particular, melted and ejected large portions of Earth's mantle and crust and outgassed significant amounts of steam which eventually cooled and condensed to contribute to ocean water at the end of the Hadean.: 10 


=== Second atmosphere ===

The increasing solidification of Earth's crust at the end of the Hadean closed off most of the advective heat transfer to the surface, causing the atmosphere to cool, which condensed most of the water vapor out of the air precipitating into a superocean. Further outgassing from volcanism, supplemented by gases introduced by huge asteroids during the Late Heavy Bombardment, created the subsequent Archean atmosphere, which consisted largely of nitrogen plus carbon dioxide, methane and inert gases. A major part of carbon dioxide emissions dissolved in water and reacted with metals such as calcium and magnesium during weathering of crustal rocks to form carbonates that were deposited as sediments. Water-related sediments have been found that date from as early as 3.8 billion years ago.
About 3.4 billion years ago, nitrogen formed the major component of the then-stable "second atmosphere". The influence of the evolution of life has to be taken into account rather soon in the history of the atmosphere because hints of earliest life forms appeared as early as 3.5 billion years ago. How Earth at that time maintained a climate warm enough for liquid water and life, if the early Sun put out 30% lower solar radiance than today, is a puzzle known as the "faint young Sun paradox".
The geological record however shows a continuous relatively warm surface during the complete early temperature record of Earth – with the exception of one cold glacial phase about 2.4 billion years ago. In the late Neoarchean, an oxygen-containing atmosphere began to develop, apparently due to a billion years of cyanobacterial photosynthesis (see Great Oxygenation Event), which have been found as stromatolite fossils from 2.7 billion years ago. The early basic carbon isotopy (isotope ratio proportions) strongly suggests conditions similar to the current, and that the fundamental features of the carbon cycle became established as early as 4 billion years ago.
Ancient sediments in the Gabon dating from between about 2.15 and 2.08 billion years ago provide a record of Earth's dynamic oxygenation evolution. These fluctuations in oxygenation were likely driven by the Lomagundi carbon isotope excursion.


=== Third atmosphere ===

The constant re-arrangement of continents by plate tectonics influences the long-term evolution of the atmosphere by transferring carbon dioxide to and from large continental carbonate stores. Free oxygen did not exist in the atmosphere until about 2.4 billion years ago during the Great Oxygenation Event and its appearance is indicated by the end of banded iron formations (which signals the depletion of substrates that can react with oxygen to produce ferric deposits) during the early Proterozoic eon.
Before this time, any oxygen produced by cyanobacterial photosynthesis would be readily removed by the oxidation of reducing substances on the Earth's surface, notably ferrous iron, sulfur and atmospheric methane. Free oxygen molecules did not start to accumulate in the atmosphere until the rate of production of oxygen began to exceed the availability of reductant materials that removed oxygen. This point signifies a shift from a reducing atmosphere to an oxidizing atmosphere. O2 showed major variations during the Proterozoic, including a billion-year period of euxinia, until reaching a steady state of more than 15% by the end of the Precambrian. The rise of the more robust eukaryotic photoautotrophs (green and red algae) injected further oxygenation into the air, especially after the end of the Cryogenian global glaciation, which was followed by an evolutionary radiation event during the Ediacaran period known as the Avalon explosion, where complex metazoan life forms (including the earliest cnidarians, placozoans and bilaterians) first proliferated. The following time span from 539 million years ago to the present day is the Phanerozoic eon, during the earliest period of which, the Cambrian, more actively moving metazoan life began to appear and rapidly diversify in another radiation event called the Cambrian explosion, whose locomotive metabolism was fuelled by the rising oxygen level.
The amount of oxygen in the atmosphere has fluctuated over the last 600 million years, reaching a peak of about 30% around 280 million years ago during the Carboniferous period, significantly higher than today's 21%. Two main processes govern changes in the atmosphere: the evolution of plants and their increasing role in carbon fixation, and the consumption of oxygen by rapidly diversifying animal faunae and also by plants for photorespiration and their own metabolic needs at night. Breakdown of pyrite and volcanic eruptions release sulfur into the atmosphere, which reacts and hence reduces oxygen in the atmosphere. However, volcanic eruptions also release carbon dioxide, which can fuel oxygenic photosynthesis by terrestrial and aquatic plants. The cause of the variation of the amount of oxygen in the atmosphere is not precisely understood. Periods with more oxygen in the atmosphere were often associated with more rapid development of animals.


== Air pollution ==

Air pollution is the introduction of airborne chemicals, particulate matter or biological materials that cause harm or discomfort to organisms. The population growth, industrialization and motorization of human societies have significantly increased the amount of airborne pollutants in the Earth's atmosphere, causing noticeable problems such as smogs, acid rains and pollution-related diseases. The depletion of stratospheric ozone layer, which shields the surface from harmful ionizing ultraviolet radiations, is also caused by air pollution, chiefly from chlorofluorocarbons and other ozone-depleting substances.
Since 1750, human activity, especially after the Industrial Revolution, has increased the concentrations of various greenhouse gases, most importantly carbon dioxide, methane and nitrous oxide. Greenhouse gas emissions, coupled with deforestation and destruction of wetlands via logging and land developments, have caused an observed rise in global temperatures, with the global average surface temperatures being 1.1 °C higher in the 2011–2020 decade than they were in 1850. It has raised concerns of man-made climate change, which can have significant environmental impacts such as sea level rise, ocean acidification, glacial retreat (which threatens water security), increasing extreme weather events and wildfires, ecological collapse and mass dying of wildlife.


== See also ==


== References ==


== External links ==

Buchan, Alexander (1878). "Atmosphere" . Encyclopædia Britannica. Vol. III (9th ed.). pp. 28–36.
Interactive global map of current atmospheric and ocean surface conditions.