# Aerobot

An aerobot is an aerial robot, usually used in the context of an uncrewed space probe or unmanned aerial vehicle.
While work has been done since the 1960s on robot "rovers" to explore the Moon and other worlds in the Solar System, such machines have limitations. They tend to be expensive and have limited range, and due to the communications time lags over interplanetary distances, they have to be smart enough to navigate without disabling themselves.
For planets with atmospheres of any substance, however, there is an alternative: an autonomous flying robot, or "aerobot".  Most aerobot concepts are based on aerostats, primarily balloons, but occasionally airships. Flying above obstructions in the winds, a balloon could explore large regions of a planet in detail for relatively low cost. Airplanes for planetary exploration have also been proposed.


== Basics of balloons ==

While the notion of sending a balloon to another planet sounds strange at first, balloons have a number of advantages for planetary exploration. They can be made light in weight and are potentially relatively inexpensive. They can cover a great deal of ground, and their view from a height gives them the ability to examine wide swathes of terrain with far more detail than would be available from an orbiting satellite. For exploratory missions, their relative lack of directional control is not a major obstacle as there is generally no need to direct them to a specific location.
Balloon designs for possible planetary missions have involved a few unusual concepts. One is the solar, or infrared (IR) Montgolfiere. This is a hot-air balloon where the envelope is made from a material that traps heat from sunlight, or from heat radiated from a planetary surface. Black is the best color for absorbing heat, but other factors are involved and the material may not necessarily be black.
Solar Montgolfieres have several advantages for planetary exploration, as they can be easier to deploy than a light gas balloon, do not necessarily require a tank of light gas for inflation, and are relatively forgiving of small leaks. They do have the disadvantage that they are only aloft during daylight hours.
The other is a "reversible fluid" balloon. This type of balloon consists of an envelope connected to a reservoir, with the reservoir containing a fluid that is easily vaporized. The balloon can be made to rise by vaporizing the fluid into gas, and can be made to sink by condensing the gas back into fluid. There are a number of different ways of implementing this scheme, but the physical principle is the same in all cases.
A balloon designed for planetary exploration will carry a small gondola containing an instrument payload. The gondola will also carry power, control, and communications subsystems. Due to weight and power supply constraints, the communications subsystem will generally be small and low power, and interplanetary communications will be performed through an orbiting planetary probe acting as a relay.
A solar Montgolfiere will sink at night, and will have a guide rope attached to the bottom of the gondola that will curl up on the ground and anchor the balloon during the darkness hours. The guide rope will be made of low friction materials to keep it from catching or tangling on ground features.
Alternatively, a balloon may carry a thicker instrumented "snake" in place of the gondola and guiderope, combining the functions of the two. This is a convenient scheme for making direct surface measurements.
A balloon could also be anchored to stay in one place to make atmospheric observations. Such a static balloon is known as an "aerostat".
One of the trickier aspects of planetary balloon operations is inserting them into operation. Typically, the balloon enters the planetary atmosphere in an "aeroshell", a heat shield in the shape of a flattened cone. After atmospheric entry, a parachute will extract the balloon assembly from the aeroshell, which falls away. The balloon assembly then deploys and inflates.
Once operational, the aerobot will be largely on its own and will have to conduct its mission autonomously, accepting only general commands over its long link to Earth. The aerobot will have to navigate in three dimensions, acquire and store science data, perform flight control by varying its altitude, and possibly make landings at specific sites to provide close-up investigation.


=== The Venus Vega balloons ===

The first, and so far only, planetary balloon mission was performed by the Space Research Institute of Soviet Academy of Sciences in cooperation with the French space agency CNES in 1985. A small balloon, similar in appearance to terrestrial weather balloons, was carried on each of the two Soviet Vega Venus probes, launched in 1984.
The first balloon was inserted into the atmosphere of Venus on 11 June 1985, followed by the second balloon on 15 June 1985. The first balloon failed after only 56 minutes, but the second operated for a little under two Earth days until its batteries ran down.
The Venus Vega balloons were the idea of Jacques Blamont, chief scientist for CNES and the father of planetary balloon exploration. He energetically promoted the concept and enlisted international support for the small project.
The scientific results of the Venus VEGA probes were modest. More importantly, the clever and simple experiment demonstrated the validity of using balloons for planetary exploration.


=== The Mars aerobot effort ===
After the success of the Venus VEGA balloons, Blamont focused on a more ambitious balloon mission to Mars, to be carried on a Soviet space probe.
The atmospheric pressure on Mars is about 150 times less than that of Earth. In such a thin atmosphere, a balloon with a volume of 5,000 to 10,000 cubic metres (180,000 to 350,000 cubic feet) could carry a payload of 20 kilograms (44 pounds), while a balloon with a volume of 100,000 cubic meters (3,500,000 cubic feet) could carry 200 kilograms (440 pounds).
The French had already conducted extensive experiments with solar Montgolfieres, performing over 30 flights from the late 1970s into the early 1990s. The Montgolfieres flew at an altitude of 35 kilometers, where the atmosphere was as thin and cold as it would be on Mars, and one spent 69 days aloft, circling the Earth twice.
Early concepts for the Mars balloon featured a "dual balloon" system, with a sealed hydrogen or helium-filled balloon tethered to a solar Montgolfiere. The light-gas balloon was designed to keep the Montgolfiere off the ground at night. During the day, the Sun would heat up the Montgolfiere, causing the balloon assembly to rise.
Eventually, the group decided on a cylindrical sealed helium balloon made of aluminized PET film, and with a volume of 5,500 cubic meters (190,000 cubic feet). The balloon would rise when heated during the day and sink as it cooled at night.
Total mass of the balloon assembly was 65 kilograms (143 pounds), with a 15 kilograms (33 pounds) gondola and a 13.5 kilograms (30 pounds) instrumented guiderope. The balloon was expected to operate for ten days. Unfortunately, although considerable development work was performed on the balloon and its subsystems, Russian financial difficulties pushed the Mars probe out from 1992, then to 1994, and then to 1996. The Mars balloon was dropped from the project due to cost.


== JPL aerobot experiments ==
By this time, the Jet Propulsion Laboratory (JPL) of the US National Aeronautics and Space Administration (NASA) had become interested in the idea of planetary aerobots, and in fact a team under Jim Cutts of JPL had been working on concepts for planetary aerobots for several years, as well as performing experiments to validate aerobot technology.
The first such experiments focused on a series of reversible-fluid balloons, under the project name ALICE, for "Altitude Control Experiment". The first such balloon, ALICE 1, flew in 1993, with other flights through ALICE 8 in 1997.
Related work included the characterization of materials for a Venus balloon envelope, and two balloon flights in 1996 to test instrument payloads under the name BARBE, for "Balloon Assisted Radiation Budget Equipment".
By 1996, JPL was working on a full-fledged aerobot experiment named PAT, for "Planetary Aerobot Testbed", which was intended to demonstrate a complete planetary aerobot through flights into Earth's atmosphere. PAT concepts envisioned a reversible-fluid balloon with a 10-kilogram payload that would include navigation and camera systems, and eventually would operate under autonomous control. The project turned out to be too ambitious, and was cancelled in 1997. JPL continued to work on a more focused, low-cost experiments to lead to a Mars aerobot, under the name MABVAP, for "Mars Aerobot Validation Program". MABVAP experiments included drops of balloon systems from hot-air balloons and helicopters to validate the tricky deployment phase of a planetary aerobot mission, and development of envelopes for superpressure balloons with materials and structures suited to a long-duration Mars mission.
JPL also provided a set of atmospheric and navigation sensors for the Solo Spirit round-the-world manned balloon flights, both to support the balloon missions and to validate technologies for planetary aerobots.
While these tests and experiments were going on, JPL performed a number of speculative studies for planetary aerobot missions to Mars, Venus, Saturn's moon Titan, and the outer planets.


=== Mars ===
JPL's MABVAP technology experiments were intended to lead to an actual Mars aerobot mission, named MABTEX, for "Mars Aerobot Technology Experiment". As its name implies, MABTEX was primarily intended to be an operational technology experiment as a precursor to a more ambitious efforts. MABTEX was envisioned as a small superpressure balloon, carried to Mars on a "microprobe" weighing no more than 40 kilograms (88 lb). Once inserted, the operational balloon would have a total mass of no more than 10 kilograms (22 lb) and would remain operational for a week. The small gondola would have navigational and control electronics, along with a stereo imaging system, as well as a spectrometer and magnetometer.
Plans envisioned a follow-on to MABTEX as a much more sophisticated aerobot named MGA, for "Mars Geoscience Aerobot". Design concepts for MGA envisioned a superpressure balloon system very much like that of MABTEX, but much larger. MGA would carry a payload ten times larger than that of MABTEX, and would remain aloft for up to three months, circling Mars more than 25 times and covering over 500,000 kilometres (310,000 mi). The payload would include sophisticated equipment, such as an ultrahigh resolution stereo imager, along with oblique imaging capabilities; a radar sounder to search for subsurface water; an infrared spectroscopy system to search for important minerals; a magnetometer; and weather and atmospheric instruments. MABTEX might be followed in turn by a small solar-powered blimp named MASEPA, for "Mars Solar Electric Propelled Aerobot".


=== Venus ===
JPL has also pursued similar studies on Venus aerobots. A Venus Aerobot Technology Experiment (VEBTEX) has been considered as a technology validation experiment, but the focus appears to have been more on full operational missions. One mission concept, the Venus Aerobot Multisonde (VAMS), envisions an aerobot operating at altitudes above 50 kilometres (31 mi) that would drop surface probes, or "sondes", onto specific surface targets. The balloon would then relay information from the sondes directly to Earth, and would also collect planetary magnetic field data and other information. VAMS would require no fundamentally new technology, and may be appropriate for a NASA low-cost Discovery planetary science mission.
Significant work has been performed on a more ambitious concept, the Venus Geoscience Aerobot (VGA). Designs for the VGA envision a relatively large reversible-fluid balloon, filled with helium and water, that could descend to the surface of Venus to sample surface sites, and then rise again to high altitudes and cool off.
Developing an aerobot that can withstand the high pressures and temperatures (up to 480 degrees Celsius, or almost 900 degrees Fahrenheit) on the surface of Venus, as well as passage through sulfuric acid clouds, will require new technologies. As of 2002, VGA was not expected to be ready until late in the following decade. Prototype balloon envelopes have been fabricated from polybenzoxazole, a polymer that exhibits high strength, resistance to heat, and low leakage for light gases. A gold coating is applied to allow the polymer film to resist corrosion from acid clouds.
Work has also been done on a VGA gondola weighing about 30 kilograms (66 lb). In this design, most instruments are contained in a spherical pressure vessel with an outer shell of titanium and an inner shell of stainless steel. The vessel contains a solid-state camera and other instruments, as well as communications and flight control systems. The vessel is designed to tolerate pressures of up to a hundred atmospheres and maintain internal temperatures below 30 °C (86 °F) even on the surface of Venus. The vessel is set at the bottom of a hexagonal "basket" of solar panels that in turn provide tether connections to the balloon system above, and is surrounded by a ring of pipes acting as a heat exchanger. An S-band communications antenna is mounted on the rim of the basket, and a radar antenna for surface studies extends out of the vessel on a mast.
The Venus Atmospheric Maneuverable Platform (VAMP) is a mission concept by the aerospace companies Northrop Grumman and LGarde for a powered, long endurance, semi-buoyant inflatable aircraft that would explore the upper atmosphere of Venus for biosignatures as well as perform atmospheric measurements.
In April 2021 it was reported that NASA allocated work to design and test robotic balloons for future exploration of Venus.


=== Titan ===
Titan, the largest moon of Saturn, is an attractive target for aerobot exploration, as it has a nitrogen atmosphere five times as dense as that of Earth's that contains a smog of organic photochemicals, hiding the moon's surface from view by visual sensors. An aerobot would be able to penetrate this haze to study the moon's mysterious surface and search for complex organic molecules. NASA has outlined a number of different aerobot mission concepts for Titan, under the general name of Titan Biologic Explorer.
One concept, known as the Titan Aerobot Multisite mission, involves a reversible-fluid balloon filled with argon that could descend from high altitude to the surface of the moon, perform measurements, and then rise again to high altitude to perform measurements and move to a different site. Another concept, the Titan Aerobot Singlesite mission, would use a superpressure balloon that would select a single site, vent much of its gas, and then survey that site in detail.
An ingenious variation on this scheme, the Titan Aerover, combines aerobot and rover. This vehicle features a triangular frame that connects three balloons, each about two meters (6.6 feet) in diameter. After entry into Titan's atmosphere, the aerover would float until it found an interesting site, then vent helium to descend to the surface. The three balloons would then serve as floats or wheels as necessary. JPL has built a simple prototype that looks like three beachballs on a tubular frame.
No matter what form the Titan Biologic Explorer mission takes, the system would likely require an atomic-powered radioisotope thermoelectric generator module for power. Solar power would not be possible at Saturn's distance and under Titan's smog, and batteries would not give adequate mission endurance. The aerobot would also carry a miniaturized chemical lab to search for complicated organic chemicals.
Outside of JPL, other mission studies of Titan aerobot concepts have included studies of airships by MIT and NASA Glenn, and a proposed Titan airplane proposed by NASA Ames.


=== Jupiter ===
Finally, aerobots might be used to explore the atmosphere of Jupiter and possibly the other gaseous outer planets. As the atmospheres of these planets are largely composed of hydrogen, and since there is no lighter gas than hydrogen, such an aerobot would have to be a Montgolfiere. As sunlight is weak at such distances, the aerobot would obtain most of its heating from infrared energy radiated by the planet below.
A Jupiter aerobot might operate at altitudes where the air pressure ranges from one to ten atmospheres, occasionally dropping lower for detailed studies. It would make atmospheric measurements and return imagery and remote sensing of weather phenomena, such as Jupiter's Great Red Spot. A Jupiter aerobot might also drop sondes deep into the atmosphere and relay their data back to an orbiter until the sondes are destroyed by temperature and pressure.


== Planetary aircraft ==

Winged airplane concepts have been proposed for robotic exploration in the atmosphere of Mars, Venus, Titan, and even Jupiter.
The main technical challenges of flying on Mars include:

Understanding and modeling the low Reynolds number, high subsonic Mach Number aerodynamics
Building appropriate, often unconventional airframe designs and aerostructures
Mastering the dynamics of deployment from a descending entry vehicle aeroshell
Integrating a non-air-breathing propulsion subsystem into the system.
An aircraft concept, ARES was selected for a detailed design study as one of the four finalists for the 2007 Mars Scout Program opportunity, but was eventually not selected in favor of the Phoenix mission. In the design study, both half-scale and full-scale aircraft were tested under Mars-atmospheric conditions. (See also Mars airplane.)


== Planetary rotorcraft ==

In 2002, a paper was published suggesting autonomous robotic helicopters for Mars exploration, possible for the Mars Scout Program. A number of advantages of a viable rotorcraft design were noted, including the ability to pass over difficult Mars terrain yet still visit multiple sites in situ. The short hop made by Lunar Surveyor 6 in 1967 was noted as example of hopping to visit another site.
Ingenuity, part of NASA's Mars 2020 mission, is a defunct robotic helicopter that demonstrated the first rotorcraft flight in the atmosphere of Mars. The aircraft was deployed from the Perseverance rover, and initially flew five times during its 30-day test campaign early in the mission. Each flight took no more than 110 seconds, at altitudes ranging from 3 to 10 meters (10 to 33 ft) off the ground, and covered a maximum distance of up to 266 m (873 ft) per flight. It used autonomous control and communicated with Perseverance directly after each landing. It achieved the first powered flight on another planet. Ingenuity had been operating on Mars for 1042 sols (1071 total days; 1 year, 341 days) before retirement, when all four of its rotor blades were likely damaged, causing NASA to retire the craft.
NASA's Dragonfly mission, planned for 2027, will feature a rotorcraft which will explore Titan.


== See also ==
Titan Winged Aerobot


== Notes ==


== References ==


== External links ==
Modern Ballooning: Planetary Aerobots
Overview of Innovative Aircraft Power and Propulsion Systems and Their Applications for Planetary Exploration
Ares Mars Airplane